<!doctype html>
<html lang="en">
<head>
	<title>PHP WEB</title>
</head>
<body>
<?php
    require("/layouts/defaultLayout.php");
?>
