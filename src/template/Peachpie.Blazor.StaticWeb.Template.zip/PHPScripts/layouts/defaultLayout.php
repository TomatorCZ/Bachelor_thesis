<div>
<a href="/about/me.php">About Me</a>
<a href="/about/company.php">About Company</a>
<a href="/community/developers.php">Developers</a>
</div>