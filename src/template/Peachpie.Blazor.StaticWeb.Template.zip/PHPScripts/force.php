﻿<?php
class force{}