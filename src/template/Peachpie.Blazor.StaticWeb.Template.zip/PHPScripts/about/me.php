<?php
    require("/headers/defaultHeader.php");
?>

<h1>Me</h1>
<p>Something about me...</p>
<p>This image will not be displayed, when you are in the offline mode</p>
<img alt="Logo" src="Web/images/logo.png"/>

<?php
    require("/footers/defaultFooter.php");
?>